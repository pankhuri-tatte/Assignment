package com.test.assignment_26nov;
import java.util.Scanner;
public class fibonacci {
	static void DisplayFibonacci(int n)
	{
		int n1=0,n2=1,n3=1,n4=2,n5=0;
		//Displays th first four terms of the series
		System.out.print(n1+ "," +n2+ "," +n3+ "," +n4);
		//adds the previous four digits and prints the sum as next term of series
		for(int i=0; i<n-4; i++)
		{
			n5=n1+n2+n3+n4;
			System.out.print("," +n5);
			n1=n2;
			n2=n3;
			n3=n4;
			n4=n5;
		}
	}

	public static void main(String[] args) {
		int n;
		System.out.println("Enter the number upto which series is to be printed");
		Scanner sc= new Scanner(System.in);
		n=sc.nextInt();
		//Passed number of terms to be displayed in the series
		DisplayFibonacci(n); 

	}

}
