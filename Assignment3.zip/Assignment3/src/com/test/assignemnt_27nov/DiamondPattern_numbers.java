package com.test.assignemnt_27nov;

/**
 * The program prints the stars in diamond pattern.
 * First the upper half is printed and then lower half
 *
 */
public class DiamondPattern_numbers {

	public static void main(String[] args) {
		int row=5,i,j,sp;
		
		//Printing upper half of the pattern
		for(i=1; i<=row/*exits when i reaches mid line*/ ;i++)
		{
			//loop to print spaces
			for(sp=row; sp>=i; sp--)
			{
				System.out.print(" ");
			}
			//loop to print numbers
			for(j=1; j<=i; j++)
			{
				System.out.print(i+" ");
			}
			//for new line
			System.out.println(" ");
		}
		//Printing lower half of the pattern
		for(i=row-1; i>=1; i--)
		{
			//loop to print spaces
			for(sp=row-1; sp>=i-1; sp--) 
			{
				System.out.print(" ");
			}
			//loop to print numbers
			for(j=1; j<=i; j++)
			{
				System.out.print(i+" ");
			}
			//for new line
			System.out.println();
		}
	}		
}

