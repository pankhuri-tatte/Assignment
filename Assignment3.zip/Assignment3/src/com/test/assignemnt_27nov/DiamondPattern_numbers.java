package com.test.assignemnt_27nov;

public class DiamondPattern_numbers {

	public static void main(String[] args) {
		int row=9,n,i,j,sp;
		int mid=(row+1)/2;
		//Printing upper half of the pattern
		for(i=1;i<=mid;/*exits when i reaches mid line*/ i++)
		{
			//prints space
			for(sp=1;sp<=(mid-i);sp++)
			{
				System.out.print(" ");
			}
			//prints numbers
			for(j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println(" ");
		}
		//Printing lower half of the pattern
		for(i=1;i<=(mid-1); /*exits when i reaches mid-1*/ i++)
		{
			//prints space
			for(sp=1;sp<=i;i++) 
			{
				System.out.print(" ");
			}
			//prints numbers
			for(j=(mid-1);j>=1;j--,mid--)
			{
				System.out.print(row-i);
			}
			System.out.println();
		}
	}		
}

