package com.test.assignemnt_27nov;

public class Diamondpattern_star {

	/**
	 * The program prints the numbers in diamond pattern.
     * First the upper half is printed and then lower half
	 */
	public static void main(String[] args) {
		int i,j,sp,row=5;
		
		//Printing upper half of the pattern
		for(i=1; i<=row /*exits when i reaches to the count of row*/; i++)
		{
			//loop to print spaces
			for(sp=row; sp>=i; sp--)
			{
				System.out.print(" ");
			}
			//loop to print the star
			for(j=1; j<=i; j++)
			{
				System.out.print("* ");
			}
			//for new line
			System.out.println(" ");
		}
		//Printing lower half of the pattern
		for(i=row-1;i>=1; /*exits when i equals*/ i--)
		{
			//loop to print spaces
			for(sp=row-1; sp>=i-1; sp--) 
			{
				System.out.print(" ");
			}
			//loop to print star
			{
			for(j=1; j<=i; j++)
			{
				System.out.print("* ");
			}
			//prints new line 
			System.out.println();
		}
	}		
}
}

