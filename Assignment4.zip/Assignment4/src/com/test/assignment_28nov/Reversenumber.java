package com.test.assignment_28nov;
import java.util.Scanner;

public class Reversenumber {

	public static void main(String[] args) {
		int n;
		String rnum="";
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		int length=String.valueOf(n).length();
		for(int i=1;i<=length;i++)
		{
			int rem=n%10;
			rnum=rnum+rem;
			n=n/10;
		}
		System.out.println(rnum);
		
	}

}
