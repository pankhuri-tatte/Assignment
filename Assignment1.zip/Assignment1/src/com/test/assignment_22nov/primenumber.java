package com.test.assignment_22nov;
import java.util.Scanner;

/**
 * The program calculates and prints all the prime numbers upto the number entered
 * by the user.
 *
 */
public class primenumber {
	static void findprime(int num)
	{ 
	  int flag=0;
	  
	  //checks for the prime number
	  for(int i=2; i<num /*exits the loop when i exceeds num*/; i++)
	  {
		  if(num%i==0)
			  flag=1;
	  }
	  if(flag==0)
		  System.out.println(num+ " is a prime number");
	  else
		  System.out.println(num+ " is not a prime number");
	}

	public static void main(String[] args) 
	{
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		
		//inputs the number
		num = sc.nextInt();
		//function to find prime numbers
		findprime(num);
	}
}


