package com.test.assignment_22nov;
import java.util.Scanner;

/**
 * The program calculates the largest element of the array. 
 *
 */
public class largestnum {

	public static void main(String[] args) {
		
		int[] arr = new int[] {5,8,2};  //declared an array with values
		int max = arr[0];
		
		//logic for calculating the maximum of the array
		
		for(int i=1; i<arr.length /*exits the loop when i exceeds length */; i++)
		{
		   if(arr[i]>max)
			   max=arr[i];
		}
		System.out.println(+max);   //prints the maximum of all the elements
	}

}
