package com.test.assignment_22nov;
import java.util.Scanner;

public class largestnum {

	public static void main(String[] args) {
		int[] arr = new int[] {5,8,2};  //declared an array with values
		int max = arr[0];
		for(int i=1; i<arr.length; i++)
		{
		   if(arr[i]>max)
			   max=arr[i];
		}
		System.out.println(+max);   //prints the maximum of all the elements
	}

}
