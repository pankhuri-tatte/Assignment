package com.test.assignment_22nov;
import java.util.*;

public class Electricity_bill {

	public static void main(String[] args) {
		long unit;
		double bill=0;
		System.out.println("Enter the number of units");
		Scanner sc = new Scanner(System.in);
		unit = sc.nextLong();
		if(unit<100)            //executes when unit is less than 100
		{
			System.out.println("The bill amount is " +(unit*10));
		}
		else if(unit<300)     //executes when unit is between 100 and 200
		{
			System.out.println("The bill amount is " +((100*5)+(unit-100)*10));
		}
		else if(unit>=300)    //executes when unit is greater than 300
		{
			System.out.println("The bill amount is " +((100*5)+(200*10)+(unit-300)*20));
		}
		

	}

}
