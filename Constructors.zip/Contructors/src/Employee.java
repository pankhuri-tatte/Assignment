
public class Employee {
	int age;
	long salary;
	String name,city,dob;
	public Employee()
	{
	}
	public Employee(String name,int age,String dob,String city,long salary)
	{
	  this.name=name;
	  this.age=age;
	  this.dob=dob;
	  this.city=city;
	  this.salary=salary;
	  
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public static void main(String[] args)
	{
		Employee dobj = new Employee();
		Employee dobj1 = new Employee();
		Employee dobj2 = new Employee();
		Employee dobj3 = new Employee();
		Employee dobj4 = new Employee();
		Employee pobj = new Employee("Anna", 25, "09-09-97", "Delhi", 40000);
		Employee pobj1 = new Employee("Bob", 26, "10-09-97", "Mumbai", 50000);
		Employee pobj2 = new Employee("Charles", 27, "11-09-97", "Delhi", 60000);
		Employee pobj3 = new Employee("Derek", 28, "12-09-97", "Banglore", 70000);
		Employee pobj4 = new Employee("Rachel", 35, "13-09-97", "Delhi", 80000);
		//Setting values using setters
		//Employee 1
		dobj.setName("Anna");
		dobj.setAge(25);
		dobj.setDob("09-09-97");
		dobj.setCity("Delhi");
		dobj.setSalary(40000);
		//Employee 2
		dobj1.setName("Bob");
		dobj1.setAge(26);
		dobj1.setDob("10-09-97");
		dobj1.setCity("Mumbai");
		dobj1.setSalary(50000);
		//Employee 3
		dobj2.setName("Charles");
		dobj2.setAge(27);
		dobj2.setDob("11-09-97");
		dobj2.setCity("Delhi");
		dobj2.setSalary(60000);
		//Employee 4
		dobj3.setName("Derek");
		dobj3.setAge(28);
		dobj3.setDob("12-09-97");
		dobj3.setCity("Banglore");
		dobj3.setSalary(70000);
		//Employee 5
		dobj4.setName("Rachel");
		dobj4.setAge(35);
		dobj4.setDob("13-09-97");
		dobj4.setCity("Delhi");
		dobj4.setSalary(80000);
		//Printing a value 
		System.out.println(dobj1.age);
		
				
	}
}

